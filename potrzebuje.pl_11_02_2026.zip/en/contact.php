<?php
// en/contact.php — forward to root contact with language
$_GET['lang'] = 'en';
require_once __DIR__ . '/../contact.php';
?>