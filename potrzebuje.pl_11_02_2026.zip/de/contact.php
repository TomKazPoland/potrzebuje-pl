<?php
// de/contact.php — forward to root contact with language
$_GET['lang'] = 'de';
require_once __DIR__ . '/../contact.php';
?>